var questions = [{
	"question": "My name is",
	"option1": "Akosua",
	"option2": "Titus",
	"option3": "Oswald",
	"option4": "Bella",
	"answer": "1"
}, {
	"question": "My age is",
	"option1": "20",
	"option2": "21",
	"option3": "22",
	"option4": "23",
	"answer": "4"

}]